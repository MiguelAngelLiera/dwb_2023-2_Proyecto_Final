package com.invoice.api.dto;

public class DtoCustomer {

	private String rfc;

	public String getRfc() {
		return rfc;
	}

	public void setRfc(String rfc) {
		this.rfc = rfc;
	}

}
